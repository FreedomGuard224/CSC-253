﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
 * 29 August 2019
 * CSC - 253
 * Gonzales, Edmund
 * Population
 */

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;

            do
            {
                Console.WriteLine("1) Run program. ");
                Console.WriteLine("2) Exit. ");
                Console.Write("Enter 1 or 2: ");
                string input = Console.ReadLine();
                Console.WriteLine("");

                if (input == "1")
                {
                    double organism = 0, average = 0, days = 0, real_average = 0, day = 0, growth = 0;

                    Console.Write("Enter the number of organisms: ");
                    string input0 = Console.ReadLine();

                    if (double.TryParse(input0, out organism))
                    {
                    }
                    else
                    {
                        Console.WriteLine("Not an acceptable input. Please use numbers.");
                    }

                    Console.Write("Enter the average daily increase: ");
                    string input00 = Console.ReadLine();
                    if (double.TryParse(input00, out average))
                    {
                    }
                    else
                    {
                        Console.WriteLine("Not an acceptable input. Please use numbers.");
                    }

                    Console.Write("Enter the days left to mulitply: ");
                    string input000 = Console.ReadLine();
                    if (double.TryParse(input000, out days))
                    {
                        Console.WriteLine("");
                        Console.WriteLine($"There are {organism} organisms.");
                        Console.WriteLine($"The average daily increasea is {average}%.");
                        Console.WriteLine($"There are {days} days to multiply.");
                    }
                    else
                    {
                        Console.WriteLine("Not an acceptable input. Please use numbers.");
                    }

                    real_average = average / 100;

                    Console.WriteLine("");
                    Console.WriteLine("Day               Approximate Population");
                    Console.WriteLine("----------------------------------------");
                    Console.WriteLine($"1                      {organism}");

                    for (day = 2; day <= days; day++)
                    {
                        growth = organism * real_average;
                        organism = organism + growth;
                        Console.WriteLine($"{day}                      {organism}");
                    }
                    Console.WriteLine("");
                    Console.Write("Press enter.");
                    Console.ReadLine();
                    Console.WriteLine("");                   
                }
                else if (input == "2")
                {
                    exit = true;
                }
                else
                {
                    Console.WriteLine("That is not an option!");
                    Console.WriteLine("");
                }

            } while (exit == false);
        }
    }
}
//string organismLabel = $"{organism:n}";
//Console.WriteLine($"{organismLabel}");
//Console.WriteLine(organism.ToString("N"));