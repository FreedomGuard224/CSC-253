﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoLibrary
{
    public class Car
    {
        private string _make;
        private int _speed;
        private int _year;

        public Car()
        {
            Make = "";
            Speed = 0;
            Year = 0;
        }
        public Car(string make, int speed, int year)
        {
            Make = make;
            Speed = speed;
            Year = year;
        }
        public string Make
        {
            get{ return _make; }
            set{ _make = value; }
        }

        public int Speed
        {
            get { return _speed; }
            set { _speed = value; }
        }

        public int Year
        {
            get { return _year; }
            set { _year = value; }
        }

        public void Accelarate(int input)
        {
            _speed += input;
        }
        public void Brake(int input)
        {
            _speed += -input;
        }

        public void Accelerate(string input)
        {
            int num;

            if (int.TryParse(input, out num))
            { _speed += num; }
            else
            {
                Console.WriteLine("Not a valid number");
            }
        }

        public void Brake(string input)
        {
            int num;

            if (int.TryParse(input, out num))
            { _speed += -num; }
            else
            { Console.WriteLine("Not a valid number"); }
        }
    }
}
