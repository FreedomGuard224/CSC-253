﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary;

/**
* 22 Oct 2019
* CSC 253
* Edmund Gonzales
* Team Leader
*/

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;

            do
            {
                Console.WriteLine("1) Run program");
                Console.WriteLine("2) Exit");
                Console.WriteLine("Pick an option: ");
                string input = Console.ReadLine();

                if (input == "1")
                {
                    TeamLeader leader1 = new TeamLeader();

                    Console.WriteLine("Enter a name: ");
                    string input1 = Console.ReadLine();
                    leader1.Name = input1;

                    Console.WriteLine($"Enter {leader1.Name}'s shift number ");
                    Console.WriteLine("1,2, or 3: ");
                    string input11 = Console.ReadLine();
                    if (int.TryParse(input11, out int shift1))
                        leader1.ShiftNumber = shift1;

                    Console.WriteLine($"Enter {leader1.Name}'s hourly pay rate: ");
                    string input111 = Console.ReadLine();
                    if (int.TryParse(input111, out int pay1))
                        leader1.HourlyRate = pay1;

                    Console.WriteLine($"Enter {leader1.Name}'s monthly bonus: ");
                    string input1111 = Console.ReadLine();
                    if (int.TryParse(input1111, out int bonus1))
                        leader1.MonthlyBonus = bonus1;

                    Console.WriteLine($"Enter {leader1.Name}'s required training hours: ");
                    string input11111 = Console.ReadLine();
                    if (int.TryParse(input11111, out int required1))
                        leader1.RequiredTraining = required1;

                    Console.WriteLine($"Enter {leader1.Name}'s completed training hours: ");
                    string input111111 = Console.ReadLine();
                    if (int.TryParse(input111111, out int attended1))
                        leader1.AttendedTraining = attended1;

                    Console.WriteLine($"{leader1.Name}'s works the {leader1.ShiftNumber} shift at {leader1.HourlyRate} dollars an hour.");
                    Console.WriteLine($" Their monthly bonus is {leader1.MonthlyBonus} dollars and they have completed {leader1.AttendedTraining}/{leader1.RequiredTraining} trainig hours.");
                }
                else if (input == "2")
                {
                    exit = true;
                }
                else
                {
                    Console.WriteLine("That is not an option!");
                }

            } while (exit == false);
        }
    }
}
