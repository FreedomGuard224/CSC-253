﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class ProductionWorker
    {
        private string _name;
        private int _shiftNumber;
        private int _hourlyRate;


        public ProductionWorker()
        {
            Name  = "";
            ShiftNumber = 0;
            HourlyRate = 0;
        }
        public ProductionWorker(string name, int shiftNumber, int hourlyRate)
        {
            _name = name;
            _shiftNumber = shiftNumber;
            _hourlyRate = hourlyRate;
        }

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
        public int ShiftNumber
        {
            get { return _shiftNumber; }
            set { _shiftNumber = value; }
        }
        public int HourlyRate
        {
            get { return _hourlyRate; }
            set { _hourlyRate = value; }
        }
    }
}
