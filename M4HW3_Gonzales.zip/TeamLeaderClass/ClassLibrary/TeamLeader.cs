﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class TeamLeader : ProductionWorker 
    {
        private int _monthlyBonus;
        private int _requiredTraining;
        private int _attendedTraining;


        public TeamLeader()
        {
        MonthlyBonus = 0;
        RequiredTraining = 0;
        AttendedTraining = 0;

    }
        public TeamLeader(int monthlyBonus, int requiredTraining, int attendedTraining)
        {
            _monthlyBonus = monthlyBonus;
            _requiredTraining = requiredTraining;
            _attendedTraining = attendedTraining;
        }

        public int MonthlyBonus
        {
            get { return _monthlyBonus; }
            set { _monthlyBonus = value; }
        }
        public int RequiredTraining
        {
            get { return _requiredTraining; }
            set { _requiredTraining = value; }
        }

        public int AttendedTraining
        {
            get { return _attendedTraining; }
            set { _attendedTraining = value; }
        }
    }
}
