﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RetailClass
{
    public class Items
    {
        private string _description;
        private int _unitsOnHand;
        private decimal _price;

        public Items()
        {
            Description = "";
            UnitsOnHand = 0;
            Price = 0;
        }
        public Items(string description, int unitsOnHand, decimal price)
        {
            Description = description;
            UnitsOnHand = unitsOnHand;
            Price = price;
        }
        public string Description
        {
            get { return _description; }
            set { _description = value; }
        }

        public int UnitsOnHand
        {
            get { return _unitsOnHand; }
            set { _unitsOnHand = value; }
        }

        public decimal Price
        {
            get { return _price; }
            set { _price = value; }
        }
    }
}