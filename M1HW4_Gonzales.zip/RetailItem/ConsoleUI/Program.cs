﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* 10 Sep 2019
* CSC 253
* Edmund Gonzales
* RetailItem
*/


namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            string description1 = "", description2 = "", description3 = "";
            int units1 = 0, units2 = 0, units3 = 0;
            decimal price1 = 0m, price2 = 0m, price3 = 0m;

            RetailClass.Items item1 = new RetailClass.Items();
            RetailClass.Items item2 = new RetailClass.Items();
            RetailClass.Items item3 = new RetailClass.Items();

            description1 = "Jacket";
            item1.Description = description1;
            units1 = 12;
            item1.UnitsOnHand = units1;
            price1 = 59.95m;
            item1.Price = price1;

            description2 = "Jeans";
            item2.Description = description2;
            units2 = 40;
            item2.UnitsOnHand = units2;
            price2 = 34.95m;
            item2.Price = price2;

            description3 = "Shirt";
            item3.Description = description3;
            units3 = 40;
            item3.UnitsOnHand = units3;
            price3 = 34.95m;
            item3.Price = price3;

            Console.WriteLine("         Description     Units On Hand       Price");
            Console.WriteLine("------------------------------------------------------");
            Console.WriteLine($"Item 1    {item1.Description}             {item1.UnitsOnHand}              {item1.Price}");
            Console.WriteLine($"Item 2    {item2.Description}              {item2.UnitsOnHand}              {item2.Price}");
            Console.WriteLine($"Item 3    {item3.Description}              {item3.UnitsOnHand}              {item3.Price}");


            Console.ReadLine();
 
        }
    }
}
