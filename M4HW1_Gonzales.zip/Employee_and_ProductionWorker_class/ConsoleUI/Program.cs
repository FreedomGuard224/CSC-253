﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary;

/**
* 22 Oct 2019
* CSC 253
* Edmund Gonzales
* Employee and Production Worker Class
*/

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;

            do
            {
                Console.WriteLine("1) Run program");
                Console.WriteLine("2) Exit");
                Console.WriteLine("Pick an option: ");
                string input = Console.ReadLine();

                if (input == "1")
                {
                    ProductionWorker productionWorker1 = new ProductionWorker();        
                    
                    Console.WriteLine("Enter a name: ");
                    string input1 = Console.ReadLine();
                    productionWorker1.Name = input1;

                    Console.WriteLine($"Enter {productionWorker1.Name}'s number: ");
                    string input11 = Console.ReadLine();
                    if(int.TryParse(input11, out int number1))
                    productionWorker1.Number = number1;

                    Console.WriteLine($"Enter {productionWorker1.Name}'s shift number ");
                    Console.WriteLine("1,2, or 3: ");
                    string input111 = Console.ReadLine();
                    if (int.TryParse(input111, out int shift1))
                        productionWorker1.ShiftNumber = shift1;

                    Console.WriteLine($"Enter {productionWorker1.Name}'s hourly pay rate: ");
                    string input1111 = Console.ReadLine();
                    if (int.TryParse(input1111, out int pay1))                 
                    productionWorker1.HourlyRate = pay1;

                    Console.WriteLine($"{productionWorker1.Name}'s number is {productionWorker1.Number}.");
                    Console.WriteLine($"They work the {productionWorker1.ShiftNumber} shift at {productionWorker1.HourlyRate} dollars an hour.");
                }
                else if (input == "2") 
                {
                    exit = true;
                }
                else
                {
                    Console.WriteLine("That is not an option!");
                }

            } while (exit == false);
        }
    }
}
