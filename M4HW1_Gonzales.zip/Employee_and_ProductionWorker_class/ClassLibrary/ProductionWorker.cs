﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class ProductionWorker : Employee
    {
        private int _shiftNumber;
        private int _hourlyRate;


        public ProductionWorker() 
        {
            ShiftNumber = 0;
            HourlyRate = 0;

        }
        public ProductionWorker(int shiftNumber, int hourlyRate) 
        {
            _shiftNumber = shiftNumber;
            _hourlyRate = hourlyRate;
        }

        public int ShiftNumber
        {
            get { return _shiftNumber; }
            set { _shiftNumber = value; }
        }
        public int HourlyRate
        {
            get { return _hourlyRate; }
            set { _hourlyRate = value; }
        }
    }
}
