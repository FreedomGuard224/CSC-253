﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
 * 10 September 2019
 * CSC - 253
 * Gonzales, Edmund
 * Hospital Charges
 */

namespace ConsoleUI
{

    class Program
    {
        static void Main(string[] args)
        {
            decimal totalCost = 0;
            bool exit = false;
           
            do
            {
                Console.WriteLine("1) Run program. ");
                Console.WriteLine("2) Exit. ");
                Console.Write("Enter 1 or 2: ");
                string input = Console.ReadLine();
                Console.WriteLine("");

                if (input == "1")
                {
                    Console.WriteLine(CalcStayCharges(ref totalCost));
                    Console.WriteLine("");
                    Console.WriteLine(CalcMisCharges(ref totalCost));
                    Console.WriteLine("");
                    CalcTotalcharges(totalCost);
                    Console.WriteLine("");

                }

                else if (input == "2")
                {
                    exit = true;
                }
            } while (exit == false);
        }

        public static string CalcStayCharges(ref decimal total)
        {
            decimal stayCharges = 0, dailyCharge = 350, days = 0;

            Console.Write("How many days did the patient stay in the hospital? ");
            string input0 = Console.ReadLine();
            if (decimal.TryParse(input0, out days))
            {
            }
            else
            {
                Console.WriteLine("Not an acceptable input. Please use numbers.");
            }

            stayCharges = days * dailyCharge;
            string stayChargesLabel = $"{stayCharges:C}";
            total += stayCharges;

            return $"For {days} days in the hospital the total room charges are {stayChargesLabel}.";
        }

        public static string CalcMisCharges(ref decimal total)
        {
            decimal medicationCharges = 0m, surgicalCharges = 0m, labCharges = 0m, rehabCharges = 0m, totalMiscCharges = 0m;

            Console.Write("What was the medication charges: ");
            string input0 = Console.ReadLine();
            if (decimal.TryParse(input0, out medicationCharges))
            {
            }
            else
            {
                Console.WriteLine("Not an acceptable input. Please use numbers.");
            }

            Console.Write("What was the surgical charges: ");
            string input00 = Console.ReadLine();
            if (decimal.TryParse(input00, out surgicalCharges))
            {
            }
            else
            {
                Console.WriteLine("Not an acceptable input. Please use numbers.");
            }

            Console.Write("What was the lab charges: ");
            string input000 = Console.ReadLine();
            if (decimal.TryParse(input000, out labCharges))
            {
            }
            else
            {
                Console.WriteLine("Not an acceptable input. Please use numbers.");
            }

            Console.Write("What was the rehabilitation charges: ");
            string input0000 = Console.ReadLine();
            if (decimal.TryParse(input0000, out rehabCharges))
            {
            }
            else
            {
                Console.WriteLine("Not an acceptable input. Please use numbers.");
            }

            totalMiscCharges = medicationCharges + surgicalCharges + labCharges + rehabCharges + totalMiscCharges;
            total += totalMiscCharges;
            string medicationChargesLabel = $"{medicationCharges:C}"; string surgicalChargesLabel = $"{surgicalCharges:C}";
            string labChargesLabel = $"{labCharges:C}"; string rehabChargesLabel = $"{rehabCharges:C}";
            string totalMiscChargesLabel = $"{totalMiscCharges:C}";

            return $"{ medicationChargesLabel} medication charges, {surgicalChargesLabel} surgical charges, {labChargesLabel} lab " +
                $"charges, and {rehabChargesLabel} rehab charges comes out to {totalMiscChargesLabel} total for miscellaneous charges.";
        }

        public static void CalcTotalcharges(decimal total)
        {
            string totalLabel = $"{total:C}";
            Console.WriteLine($"With all the charges added up, the total cost comes out to {totalLabel}.");
        }


    }
}
