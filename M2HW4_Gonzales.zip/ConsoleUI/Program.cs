﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* 12 Sep 2019
* CSC 253
* Edmund Gonzales
* Word Seperator
*/

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;
            do
            {
                Console.WriteLine("1) Run Program");
                Console.WriteLine("2) Exit");
                Console.Write("Pick an option: ");
                string option = Console.ReadLine();
                Console.WriteLine("");

                if (option == "1")
                {
                    WordCount();
                }
                else if (option == "2")
                {
                    exit = true;
                }
                else
                {
                    Console.WriteLine("Not an option!");
                }

            } while (exit == false);
        }

        public static void WordCount()
        {                    
            Console.Write("Enter a phrase running together: ");
            string input = Console.ReadLine();

            string onePhrase = input, newPhrase = "";
            int newIndex = 0;

            for (int index = 0; index < onePhrase.Length; index++)
            {
                char letter = onePhrase[index];
                //newPhrase = newPhrase + letter;
                Console.WriteLine(newPhrase);

                if (index != 0 && char.IsUpper(letter))
                {
                    //This should be lower
                    newPhrase = newPhrase.Insert(newIndex, " ");
                    newPhrase = newPhrase + letter;
                    newIndex = index + 2;
                }
                else
                {
                    newPhrase = newPhrase + letter;
                    newIndex = index + 1;
                }
            }

            Console.WriteLine("");            
            //Console.WriteLine($" {newPhrase}.");
            Console.WriteLine("");
        }
    }
}
