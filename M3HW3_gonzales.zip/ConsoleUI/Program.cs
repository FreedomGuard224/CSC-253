﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;


/**
* 10 Sep
* CSC 253
* Edmund Gonzales
* CarClass
*/

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;

            do
            {
                Console.WriteLine("1) Run program");
                Console.WriteLine("2) Exit");
                Console.Write("Pick an option: ");
                string input = Console.ReadLine();

                if (input == "1")
                {
                    Person.Persons user = new Person.Persons();
                    user = Person.PersonCreation.GetPersonInfo();
                    Writer(user);
             
                }
                else if (input == "2")
                {
                    exit = true;
                }
                else
                {
                    Console.WriteLine("That is not an option");
                }
            } while (exit == false);
        }
        public static void Writer(Person.Persons user)
        {
            try
            {
                StreamWriter outputFile;
                outputFile = File.CreateText("userInformation.txt");
                outputFile.WriteLine(user.Name);
                outputFile.WriteLine(user.Age);
                outputFile.WriteLine(user.Gender);
                outputFile.Close();
            }
            catch
            {
                Console.WriteLine("Not proper input");
            }
        }
    }
}
