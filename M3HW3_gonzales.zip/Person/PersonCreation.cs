﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Person
{
    public class PersonCreation
    {
        public static Persons GetPersonInfo()
        {
            Persons user = new Persons();
            Console.WriteLine("What is the name:  ");
            user.Name = Console.ReadLine();

            Console.WriteLine("What is the age:  ");
            string input = Console.ReadLine();
            if (int.TryParse(input, out int userAge))
            {
                user.Age = userAge;
            }

            Console.WriteLine("What is the gender:  ");
            user.Gender = Console.ReadLine();

            return user;
        }
    }
    
}
