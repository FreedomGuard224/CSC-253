﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class ShiftSupervisor : Employee
    {
        private int _annualSalary;
        private int _annualProductionBonus;


        public ShiftSupervisor()
        {
            AnnualSalary = 0;
            AnnualProductionBonus = 0;

        }
        public ShiftSupervisor(int annualSalary, int annualProductionBonus)
        {
            _annualSalary = annualSalary;
            _annualProductionBonus = annualProductionBonus;
        }

        public int AnnualSalary
        {
            get { return _annualSalary; }
            set { _annualSalary = value; }
        }
        public int AnnualProductionBonus
        {
            get { return _annualProductionBonus; }
            set { _annualProductionBonus = value; }
        }
    }
}