﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

/**
* 24 Sep 2019
* CSC 253
* Edmund Gonzales
* Random Number File Reader
*/

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;

            do
            {
                Console.WriteLine("1) Run the program");
                Console.WriteLine("2) Exit");
                Console.WriteLine("Pick an option: ");
                string input = Console.ReadLine();

                if (input == "1")
                {
                    Console.WriteLine("");
                    int number = 0, total = 0, numsRead = 0;
                    StreamReader inputFile;
                    //inputFile = File.OpenText(@"E:\CTS253\MOD3\RandomWriter\ConsoleUI\bin\Debug\randomFiles.txt");
                    inputFile = File.OpenText("randomFiles.txt");

                    while (!inputFile.EndOfStream)
                    {
                        number = int.Parse(inputFile.ReadLine());
                        Console.WriteLine(number);
                        total = total + number;
                        numsRead = numsRead + 1 ;
                    }
                    Console.WriteLine($"The total of the numbers is {total}.");
                    Console.WriteLine($"There were {numsRead} numbers read.");
                    inputFile.Close();
                    Console.WriteLine("");
                }
                else if (input == "2") 
                {
                    exit = true;
                }
            } while (exit == false);
        }
    }
}
