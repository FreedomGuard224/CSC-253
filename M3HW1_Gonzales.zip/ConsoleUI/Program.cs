﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

/**
* 24 Sep 2019
* CSC 253
* Edmund Gonzales
* Random Number File Writer
*/

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;

            do
            {
                Console.WriteLine("1) Run Program");
                Console.WriteLine("2) Exit");
                Console.WriteLine("Pick an option: ");
                string input = Console.ReadLine();

                if (input == "1")
                {
                    StreamWriter outputFile;
                    outputFile = File.CreateText("randomFiles.txt");

                    int ranNum = 0;
                    Console.WriteLine("How many random numbers do you wish to make: ");
                    string input0 = Console.ReadLine();

                    if (int.TryParse(input0, out ranNum))
                    {
                        int number = 0;
                        Random rand = new Random();                      

                        for (int count = 0; count < ranNum; count++)
                        {
                            number = rand.Next(1,100) + 1;
                            outputFile.WriteLine(number);
                        }
                    }
                    else
                    {
                        Console.WriteLine("Please select appropiate integer.");
                    }

                    outputFile.Close();
                }
                

                else if (input == "2")
                {
                    exit = true;
                }
                else
                {
                    Console.WriteLine("Not an option!");
                }

            } while (exit == false);
        }
    }
}
