﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HRLibrary;

/**
* 17 November 2019
* CSC 253
* Edmund Gonzales
* Windows Form
*/

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee employee1 = new Employee("Tom", 456, "finance", "supervisor");

            Console.WriteLine($"{employee1.Name}'s employee number is {employee1.Id} and is with the {employee1.Department} department as a {employee1.Position}.");
            Console.WriteLine("");

            Console.ReadLine();
        }
    }
}
