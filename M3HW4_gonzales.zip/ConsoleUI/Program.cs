﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

/**
* 8 Oct 2019
* CSC 253
* Edmund Gonzales
* Class File Reader
*/

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;

            do
            {
                Console.WriteLine("1) Run the program");
                Console.WriteLine("2) Exit");
                Console.WriteLine("Pick an option: ");
                string input = Console.ReadLine();

                if (input == "1")
                {
                    Console.WriteLine("");
                    Reader();
                }
                else if (input == "2")
                {
                    exit = true;
                }
            } while (exit == false);
        }
        public static void Reader()
        {
            PersonLibrary.Persons user = new PersonLibrary.Persons();
            try
            {
                StreamReader inputFile;           
                inputFile = File.OpenText("userInformation.txt");

                while (!inputFile.EndOfStream)
                {
                    user.Name = inputFile.ReadLine();
                    user.Age = int.Parse(inputFile.ReadLine());
                    user.Gender = inputFile.ReadLine();

                    Console.WriteLine(user.Name);
                    Console.WriteLine(user.Age);
                    Console.WriteLine(user.Gender);
                }
                inputFile.Close();
                Console.WriteLine("");
            }
            catch
            {
                Console.WriteLine("Wrong Input");
            }

        }
    }
}