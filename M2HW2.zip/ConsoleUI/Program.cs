﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* 12 Sep 2019
* CSC 253
* Edmund Gonzales
* AverageWord Counter
*/

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;
            do
            {
                Console.WriteLine("1) Run Program");
                Console.WriteLine("2) Exit");
                Console.Write("Pick an option: ");
                string option = Console.ReadLine();
                Console.WriteLine("");

                if (option == "1")
                {
                    WordCount();
                }
                else if (option == "2")
                {
                    exit = true;
                }
                else
                {
                    Console.WriteLine("Not an option!");
                }

            } while (exit == false);
        }

        public static void WordCount()
        {
            int finalCount = 0, average = 0, countLetter = 0;
 
            Console.Write("Enter a phrase: ");
            string input = Console.ReadLine();

            string[] phrase = input.Split(null);
            string onePhrase = input;

            foreach (char letter in onePhrase)
            {
                if (char.IsLetter(letter))
                {
                    countLetter++;
                }            
            }

            for (int count = 1; count <= phrase.Length; count++)
            {
                finalCount = count;
            }

            average = countLetter / finalCount;

            Console.WriteLine("");
            Console.WriteLine($"The total count is {finalCount}.");
            Console.WriteLine($"The average of the letters is {average}.");
            Console.WriteLine("");
        }
    }
}