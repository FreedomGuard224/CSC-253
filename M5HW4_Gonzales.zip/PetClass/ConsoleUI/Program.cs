﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StoreLibrary;

/**
* 17 Nov 2019
* CSC 253
* Edmund Gonzales
* WPF Tim Demo
*/

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            Pet dog = new Pet("Tom", "dog", 6);
            Pet cat = new Pet("Vegas", "cat", 1);
            Pet bird = new Pet("Jeffery", "bird", 4);

            Console.WriteLine($"{dog.Name} is a {dog.Type} and is {dog.Age} years old.");
            Console.WriteLine("");
            Console.WriteLine($"{cat.Name} is a {cat.Type} and is {cat.Age} years old.");
            Console.WriteLine("");
            Console.WriteLine($"{bird.Name} is a {bird.Type} and is {bird.Age} years old.");
            Console.WriteLine("");

            Console.ReadLine();
        }
    }
}
