﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* 12 Sep 2019
* CSC 253
* Edmund Gonzales
* FrequentCharacter
*/

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;
            do
            {
                Console.WriteLine("1) Run Program");
                Console.WriteLine("2) Exit");
                Console.Write("Pick an option: ");
                string option = Console.ReadLine();
                Console.WriteLine("");

                if (option == "1")
                {
                    WordCount();
                }
                else if (option == "2")
                {
                    exit = true;
                }
                else
                {
                    Console.WriteLine("Not an option!");
                }

            } while (exit == false);
        }

        public static void WordCount()
        {
            int max = 0, maxIndex = 0;
            int letterCount = 0;

            Console.Write("Enter a phrase: ");
            string input = Console.ReadLine();

            string onePhrase = input;

            int length = onePhrase.Length;
            int[] counts = new int [length]; 

            for (int countOut = 0; countOut < counts.Length; countOut++)
            {
                for (int countIn = 0; countIn < counts.Length; countIn++)
                {
                    if (onePhrase[countOut] == onePhrase[countIn])
                    {
                        char letter = onePhrase[countOut];
                        if (char.IsLetterOrDigit(letter))
                        {
                            letterCount++;
                        }
                    }                             
                }

                counts[countOut] = letterCount;
                letterCount = 0;

                if(max < counts[countOut])
                {
                    max = counts[countOut];
                    maxIndex = countOut;
                }
            }

            Console.WriteLine($"The most frequent character is {onePhrase[maxIndex]} with a count of {max}.");       
        }
    }
}
